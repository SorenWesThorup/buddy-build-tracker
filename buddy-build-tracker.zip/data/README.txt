Buddy Build Tracker - static web bundle

Files:
- index.html
- data/history.json
- data/dashboard.json

How to use in your Lovable/Codex project:
1) Create a folder in your project (e.g., /public/buddy-build-tracker/).
2) Upload index.html to that folder.
3) Create a subfolder 'data' next to index.html and upload the two JSON files there.
4) Deploy the project. Visit the path where you placed index.html (e.g., /buddy-build-tracker/).

The page uses no external libraries. It reads the JSON and renders tables for Dashboard and History.
